// const http = require('http'); cos the app.listen helps so we dnt need it
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
// const expressHbs = require('express-handlebars'); for EJS we dnt need this
const errorController = require('./controllers/error');
const sequelize = require('./util/database');

const app = express();

app.set('view engine','ejs');
app.set('views','views');

// app.engine('handlebars',expressHbs({layoutsDir: 'views/layouts/',defaultLayout: 'main-layout'}));//since its not built in like the pug
// app.set('view engine','handlebars');
// // app.set('view engine','pug');
//  app.set('views','views');

// const adminData = require('./routes/admin');
const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

// db.execute('SELECT * FROM products')
// .then(result => {
//     console.log(result[0],result[1]);
// })
// .catch(err => {
//     console.log(err);
// });




//parsing of body(incoming request)
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname,'public')));
// app.use(express.static(path.join(__dirname,'publics')));

// app.use('/admin',adminData.routes);
app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.getErrorPage);
//     (req,res,next) => {
//     // res.status(404).sendFile(path.join(__dirname,'views','add-product.html'));
//     res.status(404).render('errorPage',{pageTitle: 'Paage Not Found!'});
// });

sequelize
.sync()
.then(result => {
    //console.log(result);
    app.listen(5000);
})
.catch(err => {
    console.log(err);
});




