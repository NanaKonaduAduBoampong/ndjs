// const mongodb = require('mongodb');
// const MongoClient = mongodb.MongoClient;

// let _db;
// const mongoConnect = (callback) => {
//     MongoClient.connect( //create connection to mongodb
//         'mongodb://localhost:27017/?readPreference=primary&directConnection=true&ssl=false')
//     .then(client => {
//         console.log('Connected');
//         _db = client.db();
//         callback();
//     })
//     .catch(err => {
//         console.log(err);
//         throw err;
//     });
// };

// const getDb = () => {
//     if(_db){
//         return _db;
//     }
//     throw 'No database found!';
// }

// exports.mongoConnect = mongoConnect;
// exports.getDb = getDb;




// //mySQL and Sequelize
// // const Sequelize = require('sequelize');

// // const sequelize = new Sequelize('node-complete','root','Dev7@kngtechnologies',{
// //     dialect: 'mysql',
// //     host:'localhost'
// // });

// //module.exports = sequelize;









// // const mysql = require('mysql2');

// // const pool = mysql.createPool({
// //     host: 'localhost',
// //     user: 'root',
// //     database: 'node-complete',
// //     password:'Dev7@kngtechnologies'
// // });

// // module.exports = pool.promise();