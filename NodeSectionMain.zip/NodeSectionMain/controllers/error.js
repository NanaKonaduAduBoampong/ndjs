exports.get404 = (req, res, next) => {
  res.status(404).render("errorPage", {
      pageTitle: "Page Not Found!",
      path: "/errorPage",
      isAuthenticated: req.session.isLoggedIn,
    });
};
