const path = require('path');

const express = require('express');

const adminController = require('../controllers/admin');

// const rootDir = require('../util/path');

const router = express.Router();

// const products = [];

///admin/add-product => GET
router.get('/add-product',adminController.getAddProduct);

///admin/products => GET
router.get('/products',adminController.getProducts);
    // (req,res,next) => {
    // res.sendFile(path.join(rootDir,'views','add-product.html'));
//     res.render('add-product',{
//     pageTitle: 'Add Product',
//     path:'/admin/add-product',
//     formCSS: true,
//     productCSS: true,
//     activeAddProduct: true
// });


//admin/add-product => POST
 router.post('/add-product',adminController.postAddProduct);
 //(req,res,next) => {
//     // console.log(req.body);
//     products.push({title: req.body.title});
//     res.redirect('/');
//});

router.get('/edit-product/:productId',adminController.getEditProduct);

router.post('/edit-product',adminController.postEditProduct);

router.post('/delete-product',adminController.postDeleteProduct);
module.exports = router;
// exports.routes = router;
// exports.products = products;
// module.exports = router;
