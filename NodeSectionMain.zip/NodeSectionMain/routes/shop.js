const path = require('path');

const express = require('express');

const shopController = require('../controllers/shop');

// const rootDir = require('../util/path');
// const adminData = require('./admin');
// const { getProducts } = require('../controllers/products');

const router = express.Router();

//note: order matter since the code is parsed from top to bottom
router.get('/',shopController.getIndex);

router.get('/products',shopController.getProducts);

//router.get('/products/delete');if delete was  supposed to be part then put delete first cos sinc order the:productmust take the id and never get to the delete so put the special one first

router.get('/products/:productId',shopController.getProduct);//express supports the ':' so research abt it its not a normal route

router.get('/cart',shopController.getCart);

router.post('/cart',shopController.postCart);

router.post('/cart-deleteitem', shopController.postCartDeleteProduct);

router.get('/orders',shopController.getOrders);

router.get('/checkout',shopController.getCheckout);

// (req,res,next) => {
    // console.log('shop.js',adminData.products);
    // res.sendFile(path.join(rootDir,'views','shop.html'));
    
    // const products = adminData.products;
    // res.render('shop',{
    //     prods: products,
    //     pageTitle: 'Shop',
    //     path: '/',
    //     hasProducts: products.length > 0,
    //     activeShop: true,
    //     productCSS: true,
    // });
    
// });

module.exports = router;